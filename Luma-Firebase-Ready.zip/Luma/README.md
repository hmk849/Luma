# Luma — iOS 液态玻璃聊天 App

原生 SwiftUI iOS 26 项目，采用 Liquid Glass 风格与 Telegram 式聊天布局。已加入 Firebase iOS SDK、Firebase 初始化与手机号短信验证码登录流程。

## Firebase 配置
- `GoogleService-Info.plist` 已包含在项目中，项目 ID 为 `luma-52332`，Bundle ID 为 `app.luma.chat`。
- Firebase Console → Authentication → Sign-in method（登录方式）→ Phone（电话）→ 启用并保存。
- Authentication 的设置中按 Firebase 控制台提示配置允许的地区；可先添加 Firebase 测试电话号码进行开发测试。
- 首次使用真实手机号时，Firebase 可能会使用 reCAPTCHA 验证；测试前请确保 iPhone 能打开系统浏览器页面。
- Firebase 短信发送有配额和地区限制。

## 当前功能
- Firebase 手机号短信验证码登录
- 聊天列表、联系人、设置与私聊 UI
- 本地演示聊天消息（目前尚未接入 Firestore 实时消息同步）
- iOS 26 `.glassEffect` 液态玻璃视觉
- GitHub Actions 云端构建未签名 IPA

## GitHub Actions 云端构建
1. 将本项目所有文件上传到 GitHub 仓库，保留 `.github/workflows/ios.yml` 路径。
2. 打开仓库 Actions 页面。
3. 选择 **Build unsigned iOS IPA**，点击 **Run workflow**。
4. 完成后进入运行记录，在 Artifacts 下载 `Luma-unsigned-ipa`。

未签名 IPA 不能直接像已签名 App 一样安装到 iPhone，后续需要签名或适当部署方式。

## 注意
该项目尚未经过此环境下真实 Xcode 构建验证。Firebase 手机号登录需在 Firebase Console 启用 Phone 登录方式。当前聊天消息仍是演示数据，Firestore 实时聊天、图片上传、推送通知、语音/视频通话和端到端加密尚未实现。
