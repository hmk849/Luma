import SwiftUI

struct ChatListView: View {
    @State private var searchText = ""
    @State private var chats = DemoData.chats
    @State private var selectedChat: Chat?

    private var filteredChats: [Chat] {
        let sorted = chats.sorted { $0.isPinned && !$1.isPinned }
        guard !searchText.isEmpty else { return sorted }
        return sorted.filter { $0.name.localizedCaseInsensitiveContains(searchText) || $0.message.localizedCaseInsensitiveContains(searchText) }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                LumaBackdrop()
                ScrollView {
                    VStack(spacing: 18) {
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Luma")
                                    .font(.system(size: 34, weight: .bold, design: .rounded))
                                Text("让每一次连接都更有温度")
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            Button {} label: {
                                Image(systemName: "square.and.pencil")
                                    .font(.system(size: 18, weight: .semibold))
                                    .foregroundStyle(.primary)
                                    .frame(width: 46, height: 46)
                                    .background(.ultraThinMaterial, in: Circle())
                                    .glassEffect(.regular, in: .circle)
                            }
                            .buttonStyle(.plain)
                        }
                        .padding(.horizontal, 20)
                        .padding(.top, 12)

                        HStack(spacing: 10) {
                            Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                            TextField("搜索消息或联系人", text: $searchText)
                                .textInputAutocapitalization(.never)
                        }
                        .padding(14)
                        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                        .overlay {
                            RoundedRectangle(cornerRadius: 18, style: .continuous).strokeBorder(.white.opacity(0.32), lineWidth: 1)
                        }
                        .glassEffect(.regular, in: .rect(cornerRadius: 18))
                        .padding(.horizontal, 20)

                        HStack {
                            Text("最近消息")
                                .font(.system(size: 19, weight: .bold))
                            Spacer()
                            Text("\(chats.count) 个对话")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        .padding(.horizontal, 22)

                        LazyVStack(spacing: 9) {
                            ForEach(filteredChats) { chat in
                                Button {
                                    selectedChat = chat
                                } label: {
                                    ChatRow(chat: chat)
                                }
                                .buttonStyle(.plain)
                            }
                        }
                        .padding(.horizontal, 14)
                        .padding(.bottom, 24)
                    }
                }
            }
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(item: $selectedChat) { chat in
                ConversationView(chat: chat)
            }
        }
    }
}

struct ChatRow: View {
    let chat: Chat

    private var avatarColors: [Color] {
        [
            [Color(red: 0.99, green: 0.61, blue: 0.48), Color(red: 0.91, green: 0.36, blue: 0.51)],
            [Color(red: 0.43, green: 0.67, blue: 0.99), Color(red: 0.42, green: 0.42, blue: 0.91)],
            [Color(red: 0.36, green: 0.83, blue: 0.73), Color(red: 0.16, green: 0.61, blue: 0.67)],
            [Color(red: 0.99, green: 0.77, blue: 0.38), Color(red: 0.96, green: 0.52, blue: 0.30)],
            [Color(red: 0.72, green: 0.58, blue: 0.98), Color(red: 0.48, green: 0.39, blue: 0.87)],
            [Color(red: 0.45, green: 0.78, blue: 0.94), Color(red: 0.28, green: 0.55, blue: 0.82)]
        ][chat.colorIndex % 6]
    }

    var body: some View {
        HStack(spacing: 13) {
            ZStack(alignment: .bottomTrailing) {
                Circle()
                    .fill(LinearGradient(colors: avatarColors, startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 55, height: 55)
                    .overlay {
                        Text(chat.initials)
                            .font(.system(size: 21, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                    }
                if chat.isOnline {
                    Circle().fill(Color.green).frame(width: 13, height: 13).overlay(Circle().stroke(.background, lineWidth: 2))
                }
            }
            VStack(alignment: .leading, spacing: 6) {
                HStack(spacing: 5) {
                    Text(chat.name).font(.system(size: 16, weight: .semibold)).lineLimit(1)
                    if chat.isPinned {
                        Image(systemName: "pin.fill").font(.system(size: 10)).foregroundStyle(.tertiary)
                    }
                    Spacer(minLength: 3)
                    Text(chat.time).font(.system(size: 11, weight: chat.unread > 0 ? .semibold : .regular)).foregroundStyle(chat.unread > 0 ? LumaTheme.accent : Color.secondary)
                }
                HStack(spacing: 8) {
                    Text(chat.message)
                        .font(.system(size: 13))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                    Spacer(minLength: 2)
                    if chat.unread > 0 {
                        Text(chat.unread > 99 ? "99+" : "\(chat.unread)")
                            .font(.system(size: 11, weight: .bold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 7)
                            .padding(.vertical, 4)
                            .background(LumaTheme.accent, in: Capsule())
                    }
                }
            }
        }
        .padding(.horizontal, 13)
        .padding(.vertical, 12)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 22, style: .continuous).strokeBorder(.white.opacity(0.28), lineWidth: 1)
        }
        .glassEffect(.regular, in: .rect(cornerRadius: 22))
    }
}
