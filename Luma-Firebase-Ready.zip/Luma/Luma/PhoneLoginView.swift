import SwiftUI
import FirebaseAuth

struct PhoneLoginView: View {
    let onContinue: () -> Void
    @State private var countryCode = "+1"
    @State private var phoneNumber = ""
    @State private var verificationCode = ""
    @State private var verificationID: String?
    @State private var isSending = false
    @State private var isVerifying = false
    @State private var showCodeEntry = false
    @State private var errorMessage: String?
    @State private var infoMessage: String?

    private var fullPhoneNumber: String {
        let digits = phoneNumber.filter(\.isNumber)
        return countryCode + digits
    }

    var body: some View {
        ZStack {
            LumaBackdrop()
            ScrollView {
                VStack(spacing: 0) {
                    Spacer(minLength: 28)
                    ZStack {
                        RoundedRectangle(cornerRadius: 28, style: .continuous)
                            .fill(.ultraThinMaterial)
                            .frame(width: 94, height: 94)
                            .overlay {
                                RoundedRectangle(cornerRadius: 28, style: .continuous)
                                    .strokeBorder(.white.opacity(0.55), lineWidth: 1)
                            }
                            .glassEffect(.regular, in: .rect(cornerRadius: 28))
                        Image(systemName: "bubble.left.and.bubble.right.fill")
                            .font(.system(size: 38, weight: .semibold))
                            .foregroundStyle(LinearGradient(colors: [LumaTheme.accent, LumaTheme.violet], startPoint: .topLeading, endPoint: .bottomTrailing))
                    }
                    .padding(.bottom, 28)

                    Text("开启你的对话")
                        .font(.system(size: 32, weight: .bold, design: .rounded))
                        .tracking(-0.8)
                    Text("每一条消息，都让彼此更近一步。")
                        .font(.system(size: 15))
                        .foregroundStyle(.secondary)
                        .padding(.top, 9)

                    Spacer().frame(height: 38)

                    GlassPanel {
                        VStack(alignment: .leading, spacing: 18) {
                            Text(showCodeEntry ? "短信验证码" : "手机号")
                                .font(.system(size: 14, weight: .semibold))
                                .foregroundStyle(.secondary)

                            if !showCodeEntry {
                                HStack(spacing: 12) {
                                    Menu {
                                        Button("🇺🇸 美国 (+1)") { countryCode = "+1" }
                                        Button("🇨🇳 中国 (+86)") { countryCode = "+86" }
                                        Button("🇭🇰 中国香港 (+852)") { countryCode = "+852" }
                                        Button("🇹🇼 中国台湾 (+886)") { countryCode = "+886" }
                                        Button("🇬🇧 英国 (+44)") { countryCode = "+44" }
                                        Button("🇯🇵 日本 (+81)") { countryCode = "+81" }
                                    } label: {
                                        HStack(spacing: 5) {
                                            Text(countryCode)
                                            Image(systemName: "chevron.down").font(.caption2.weight(.bold))
                                        }
                                        .font(.system(size: 16, weight: .semibold))
                                        .foregroundStyle(.primary)
                                    }
                                    Rectangle().fill(.quaternary).frame(width: 1, height: 25)
                                    TextField("输入你的手机号码", text: $phoneNumber)
                                        .keyboardType(.phonePad)
                                        .textContentType(.telephoneNumber)
                                        .font(.system(size: 17))
                                }
                                .padding(.horizontal, 15)
                                .padding(.vertical, 16)
                                .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                            } else {
                                TextField("输入短信验证码", text: $verificationCode)
                                    .keyboardType(.numberPad)
                                    .textContentType(.oneTimeCode)
                                    .font(.system(size: 19, weight: .medium))
                                    .padding(16)
                                    .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                            }

                            Text(showCodeEntry
                                 ? "请输入发送到 \(fullPhoneNumber) 的短信验证码。"
                                 : "我们将向你发送短信验证码，用于验证身份并安全登录。")
                                .font(.system(size: 13))
                                .foregroundStyle(.secondary)
                                .fixedSize(horizontal: false, vertical: true)

                            Button(action: primaryAction) {
                                HStack {
                                    if isSending || isVerifying {
                                        ProgressView().tint(.white)
                                    }
                                    Text(showCodeEntry ? "验证并登录" : "发送验证码")
                                    Spacer()
                                    Image(systemName: "arrow.right")
                                }
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundStyle(.white)
                                .padding(.horizontal, 18)
                                .padding(.vertical, 16)
                                .background(LinearGradient(colors: [LumaTheme.accent, LumaTheme.violet], startPoint: .leading, endPoint: .trailing), in: RoundedRectangle(cornerRadius: 17, style: .continuous))
                            }
                            .buttonStyle(.plain)
                            .disabled(isSending || isVerifying || (showCodeEntry ? verificationCode.isEmpty : phoneNumber.filter(\.isNumber).count < 6))

                            if showCodeEntry {
                                Button("更换手机号") {
                                    showCodeEntry = false
                                    verificationCode = ""
                                    verificationID = nil
                                    errorMessage = nil
                                }
                                .font(.system(size: 14, weight: .medium))
                                .frame(maxWidth: .infinity)
                            }

                            if let infoMessage {
                                Text(infoMessage).font(.footnote).foregroundStyle(.secondary)
                            }
                            if let errorMessage {
                                Text(errorMessage).font(.footnote).foregroundStyle(.red)
                            }
                        }
                    }
                    .padding(.horizontal, 22)

                    Text("继续即表示你同意服务条款和隐私政策。")
                        .font(.system(size: 11))
                        .foregroundStyle(.tertiary)
                        .multilineTextAlignment(.center)
                        .padding(.top, 22)
                        .padding(.horizontal, 28)
                    Spacer(minLength: 28)
                }
            }
        }
    }

    private func primaryAction() {
        if showCodeEntry {
            verifyCode()
        } else {
            sendCode()
        }
    }

    private func sendCode() {
        errorMessage = nil
        infoMessage = nil
        isSending = true
        PhoneAuthProvider.provider().verifyPhoneNumber(fullPhoneNumber, uiDelegate: nil) { id, error in
            DispatchQueue.main.async {
                isSending = false
                if let error {
                    errorMessage = error.localizedDescription
                    return
                }
                guard let id else {
                    errorMessage = "Firebase 没有返回验证码会话，请重试。"
                    return
                }
                verificationID = id
                showCodeEntry = true
                infoMessage = "验证码已请求发送，请检查短信。"
            }
        }
    }

    private func verifyCode() {
        guard let verificationID else {
            errorMessage = "验证码会话已失效，请重新发送。"
            showCodeEntry = false
            return
        }
        isVerifying = true
        errorMessage = nil
        let credential = PhoneAuthProvider.provider().credential(
            withVerificationID: verificationID,
            verificationCode: verificationCode.trimmingCharacters(in: .whitespacesAndNewlines)
        )
        Auth.auth().signIn(with: credential) { _, error in
            DispatchQueue.main.async {
                isVerifying = false
                if let error {
                    errorMessage = error.localizedDescription
                } else {
                    onContinue()
                }
            }
        }
    }
}
