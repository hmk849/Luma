import SwiftUI

struct ContactsView: View {
    @State private var searchText = ""
    private let contacts = [
        ("林间晚风", "林", true), ("Alex Chen", "A", true), ("Mia", "M", false),
        ("周末旅行计划", "旅", false), ("Sam Rivera", "S", true), ("Nora", "N", false)
    ]

    private var filtered: [(String, String, Bool)] {
        if searchText.isEmpty { return contacts }
        return contacts.filter { $0.0.localizedCaseInsensitiveContains(searchText) }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                LumaBackdrop()
                VStack(spacing: 16) {
                    HStack {
                        Text("联系人").font(.system(size: 32, weight: .bold, design: .rounded))
                        Spacer()
                        Button {} label: {
                            Image(systemName: "person.badge.plus")
                                .frame(width: 44, height: 44)
                                .background(.ultraThinMaterial, in: Circle())
                                .glassEffect(.regular, in: .circle)
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 12)

                    HStack {
                        Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                        TextField("搜索联系人", text: $searchText)
                    }
                    .padding(14)
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                    .padding(.horizontal, 18)

                    List {
                        ForEach(filtered, id: \.0) { item in
                            HStack(spacing: 13) {
                                Circle()
                                    .fill(LinearGradient(colors: [LumaTheme.accent.opacity(0.9), LumaTheme.violet], startPoint: .topLeading, endPoint: .bottomTrailing))
                                    .frame(width: 48, height: 48)
                                    .overlay(Text(item.1).font(.headline).foregroundStyle(.white))
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(item.0).font(.system(size: 16, weight: .semibold))
                                    Text(item.2 ? "在线" : "最近活跃").font(.caption).foregroundStyle(item.2 ? Color.green : Color.secondary)
                                }
                                Spacer()
                                Image(systemName: "bubble.left").foregroundStyle(.secondary)
                            }
                            .listRowBackground(Color.clear)
                        }
                    }
                    .scrollContentBackground(.hidden)
                    .listStyle(.plain)
                }
            }
            .toolbar(.hidden, for: .navigationBar)
        }
    }
}
