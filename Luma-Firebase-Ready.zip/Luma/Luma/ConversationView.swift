import SwiftUI

struct MessageItem: Identifiable {
    let id = UUID()
    var text: String
    var isOutgoing: Bool
    var time: String
}

struct ConversationView: View {
    let chat: Chat
    @State private var draft = ""
    @State private var messages: [MessageItem] = [
        MessageItem(text: "嗨！最近怎么样？", isOutgoing: false, time: "11:36"),
        MessageItem(text: "挺好的！最近发现了一个很棒的新地方。", isOutgoing: true, time: "11:38"),
        MessageItem(text: "听起来不错，周末一起去看看？🌿", isOutgoing: false, time: "11:40"),
        MessageItem(text: "那我们周末见！", isOutgoing: true, time: "11:42")
    ]

    var body: some View {
        ZStack {
            LumaBackdrop()
            VStack(spacing: 0) {
                HStack(spacing: 12) {
                    Circle()
                        .fill(LinearGradient(colors: [LumaTheme.accent, LumaTheme.violet], startPoint: .topLeading, endPoint: .bottomTrailing))
                        .frame(width: 42, height: 42)
                        .overlay(Text(chat.initials).font(.headline).foregroundStyle(.white))
                    VStack(alignment: .leading, spacing: 3) {
                        Text(chat.name).font(.system(size: 16, weight: .bold))
                        Text(chat.isOnline ? "在线" : "最近活跃")
                            .font(.system(size: 12))
                            .foregroundStyle(chat.isOnline ? .green : .secondary)
                    }
                    Spacer()
                    Button {} label: {
                        Image(systemName: "phone")
                            .frame(width: 40, height: 40)
                            .background(.ultraThinMaterial, in: Circle())
                    }
                    Button {} label: {
                        Image(systemName: "video")
                            .frame(width: 40, height: 40)
                            .background(.ultraThinMaterial, in: Circle())
                    }
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 10)
                .background(.ultraThinMaterial)
                .overlay(alignment: .bottom) { Rectangle().fill(.white.opacity(0.22)).frame(height: 1) }

                ScrollViewReader { proxy in
                    ScrollView {
                        VStack(spacing: 12) {
                            Text("今天")
                                .font(.caption.weight(.medium))
                                .foregroundStyle(.secondary)
                                .padding(.horizontal, 12)
                                .padding(.vertical, 7)
                                .background(.ultraThinMaterial, in: Capsule())
                                .padding(.vertical, 12)

                            ForEach(messages) { message in
                                HStack {
                                    if message.isOutgoing { Spacer(minLength: 48) }
                                    VStack(alignment: .trailing, spacing: 5) {
                                        Text(message.text)
                                            .font(.system(size: 15))
                                            .foregroundStyle(message.isOutgoing ? Color.white : Color.primary)
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                        HStack(spacing: 4) {
                                            Text(message.time)
                                            if message.isOutgoing {
                                                Image(systemName: "checkmark").font(.system(size: 9, weight: .bold))
                                            }
                                        }
                                        .font(.system(size: 10))
                                        .foregroundStyle(message.isOutgoing ? .white.opacity(0.72) : .secondary)
                                    }
                                    .padding(.horizontal, 14)
                                    .padding(.vertical, 10)
                                    .background {
                                        if message.isOutgoing {
                                            LinearGradient(colors: [LumaTheme.accent, LumaTheme.violet], startPoint: .topLeading, endPoint: .bottomTrailing)
                                        } else {
                                            Color(uiColor: .secondarySystemGroupedBackground).opacity(0.88)
                                        }
                                    }
                                    .clipShape(RoundedRectangle(cornerRadius: 19, style: .continuous))
                                    .overlay {
                                        RoundedRectangle(cornerRadius: 19, style: .continuous)
                                            .strokeBorder(.white.opacity(message.isOutgoing ? 0.15 : 0.42), lineWidth: 1)
                                    }
                                    if !message.isOutgoing { Spacer(minLength: 48) }
                                }
                                .id(message.id)
                            }
                        }
                        .padding(.horizontal, 13)
                        .padding(.bottom, 16)
                    }
                    .onChange(of: messages.count) {
                        if let last = messages.last { withAnimation { proxy.scrollTo(last.id, anchor: .bottom) } }
                    }
                }

                HStack(alignment: .bottom, spacing: 9) {
                    Button {} label: {
                        Image(systemName: "plus")
                            .font(.system(size: 18, weight: .semibold))
                            .frame(width: 42, height: 42)
                            .background(.ultraThinMaterial, in: Circle())
                    }
                    HStack(alignment: .bottom, spacing: 8) {
                        TextField("发送消息…", text: $draft, axis: .vertical)
                            .lineLimit(1...4)
                            .padding(.vertical, 11)
                        Button {} label: {
                            Image(systemName: "face.smiling")
                                .font(.system(size: 19))
                                .foregroundStyle(.secondary)
                        }
                        .padding(.bottom, 10)
                    }
                    .padding(.horizontal, 13)
                    .background(.ultraThinMaterial, in: Capsule())
                    .overlay { Capsule().strokeBorder(.white.opacity(0.35), lineWidth: 1) }
                    Button(action: sendMessage) {
                        Image(systemName: "arrow.up")
                            .font(.system(size: 17, weight: .bold))
                            .foregroundStyle(.white)
                            .frame(width: 42, height: 42)
                            .background(LinearGradient(colors: [LumaTheme.accent, LumaTheme.violet], startPoint: .topLeading, endPoint: .bottomTrailing), in: Circle())
                    }
                    .disabled(draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    .opacity(draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? 0.55 : 1)
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 9)
                .background(.ultraThinMaterial)
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar(.hidden, for: .navigationBar)
    }

    private func sendMessage() {
        let trimmed = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        messages.append(MessageItem(text: trimmed, isOutgoing: true, time: formatter.string(from: Date())))
        draft = ""
    }
}
