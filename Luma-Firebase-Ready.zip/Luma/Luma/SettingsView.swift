import SwiftUI

struct SettingsView: View {
    var body: some View {
        NavigationStack {
            ZStack {
                LumaBackdrop()
                ScrollView {
                    VStack(spacing: 18) {
                        Text("我的")
                            .font(.system(size: 32, weight: .bold, design: .rounded))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal, 20)
                            .padding(.top, 12)

                        GlassPanel {
                            HStack(spacing: 14) {
                                Circle()
                                    .fill(LinearGradient(colors: [LumaTheme.accent, LumaTheme.violet], startPoint: .topLeading, endPoint: .bottomTrailing))
                                    .frame(width: 68, height: 68)
                                    .overlay(Text("L").font(.system(size: 29, weight: .bold)).foregroundStyle(.white))
                                VStack(alignment: .leading, spacing: 5) {
                                    Text("Luma 用户").font(.system(size: 19, weight: .bold))
                                    Text("设置你的名字和头像").font(.subheadline).foregroundStyle(.secondary)
                                    Text("编辑个人资料  ›").font(.caption.weight(.semibold)).foregroundStyle(LumaTheme.accent)
                                }
                                Spacer()
                            }
                        }
                        .padding(.horizontal, 18)

                        VStack(spacing: 10) {
                            SettingsRow(icon: "bell.badge", title: "通知与声音", subtitle: "消息提醒与铃声")
                            SettingsRow(icon: "lock.shield", title: "隐私与安全", subtitle: "最后上线、屏蔽用户")
                            SettingsRow(icon: "paintpalette", title: "外观", subtitle: "液态玻璃与显示模式")
                            SettingsRow(icon: "internaldrive", title: "数据与存储", subtitle: "缓存与自动下载")
                            SettingsRow(icon: "questionmark.circle", title: "帮助与支持", subtitle: "常见问题与反馈")
                        }
                        .padding(.horizontal, 18)

                        Text("Luma · 预览版本 1.0")
                            .font(.caption)
                            .foregroundStyle(.tertiary)
                            .padding(.top, 8)
                    }
                    .padding(.bottom, 30)
                }
            }
            .toolbar(.hidden, for: .navigationBar)
        }
    }
}

struct SettingsRow: View {
    let icon: String
    let title: String
    let subtitle: String

    var body: some View {
        HStack(spacing: 13) {
            Image(systemName: icon)
                .font(.system(size: 18, weight: .medium))
                .foregroundStyle(LumaTheme.accent)
                .frame(width: 42, height: 42)
                .background(LumaTheme.accent.opacity(0.11), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.system(size: 15, weight: .semibold))
                Text(subtitle).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundStyle(.tertiary)
        }
        .padding(13)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay { RoundedRectangle(cornerRadius: 20, style: .continuous).strokeBorder(.white.opacity(0.28), lineWidth: 1) }
        .glassEffect(.regular, in: .rect(cornerRadius: 20))
    }
}
