import SwiftUI

struct MainTabView: View {
    var body: some View {
        TabView {
            ChatListView()
                .tabItem { Label("聊天", systemImage: "bubble.left.and.bubble.right.fill") }
            ContactsView()
                .tabItem { Label("联系人", systemImage: "person.2.fill") }
            SettingsView()
                .tabItem { Label("我的", systemImage: "person.crop.circle.fill") }
        }
        .tint(LumaTheme.accent)
    }
}
