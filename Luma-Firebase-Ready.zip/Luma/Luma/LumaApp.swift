import SwiftUI
import FirebaseCore
import FirebaseAuth

@main
struct LumaApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    @State private var isSignedIn = Auth.auth().currentUser != nil

    var body: some Scene {
        WindowGroup {
            Group {
                if isSignedIn {
                    MainTabView()
                } else {
                    PhoneLoginView {
                        withAnimation(.spring(response: 0.45, dampingFraction: 0.86)) {
                            isSignedIn = true
                        }
                    }
                }
            }
            .onOpenURL { url in
                _ = Auth.auth().canHandle(url)
            }
            .onReceive(NotificationCenter.default.publisher(for: .lumaAuthStateChanged)) { _ in
                isSignedIn = Auth.auth().currentUser != nil
            }
            .preferredColorScheme(nil)
        }
    }
}

final class AppDelegate: NSObject, UIApplicationDelegate {
    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil
    ) -> Bool {
        FirebaseApp.configure()
        Auth.auth().addStateDidChangeListener { _, user in
            DispatchQueue.main.async {
                NotificationCenter.default.post(name: .lumaAuthStateChanged, object: user != nil)
            }
        }
        return true
    }
}

extension Notification.Name {
    static let lumaAuthStateChanged = Notification.Name("lumaAuthStateChanged")
}
