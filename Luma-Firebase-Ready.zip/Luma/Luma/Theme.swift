import SwiftUI

enum LumaTheme {
    static let accent = Color(red: 0.30, green: 0.53, blue: 0.98)
    static let violet = Color(red: 0.55, green: 0.43, blue: 0.98)
    static let mint = Color(red: 0.36, green: 0.83, blue: 0.73)
    static let background = Color(uiColor: .systemGroupedBackground)
}

struct LumaBackdrop: View {
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    LumaTheme.accent.opacity(0.20),
                    LumaTheme.violet.opacity(0.12),
                    LumaTheme.mint.opacity(0.10),
                    Color(uiColor: .systemBackground)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            Circle()
                .fill(LumaTheme.accent.opacity(0.13))
                .frame(width: 250, height: 250)
                .blur(radius: 55)
                .offset(x: 135, y: -270)
            Circle()
                .fill(LumaTheme.violet.opacity(0.12))
                .frame(width: 240, height: 240)
                .blur(radius: 60)
                .offset(x: -145, y: 180)
        }
        .ignoresSafeArea()
    }
}

struct GlassPanel<Content: View>: View {
    @ViewBuilder var content: Content

    var body: some View {
        content
            .padding()
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 26, style: .continuous)
                    .strokeBorder(.white.opacity(0.34), lineWidth: 1)
            }
            .glassEffect(.regular, in: .rect(cornerRadius: 26))
    }
}
