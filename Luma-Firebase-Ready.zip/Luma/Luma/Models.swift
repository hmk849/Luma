import Foundation

struct Chat: Identifiable, Hashable {
    let id: UUID
    var name: String
    var message: String
    var time: String
    var initials: String
    var colorIndex: Int
    var unread: Int
    var isPinned: Bool
    var isOnline: Bool

    init(
        id: UUID = UUID(),
        name: String,
        message: String,
        time: String,
        initials: String,
        colorIndex: Int,
        unread: Int = 0,
        isPinned: Bool = false,
        isOnline: Bool = false
    ) {
        self.id = id
        self.name = name
        self.message = message
        self.time = time
        self.initials = initials
        self.colorIndex = colorIndex
        self.unread = unread
        self.isPinned = isPinned
        self.isOnline = isOnline
    }
}

enum DemoData {
    static let chats: [Chat] = [
        Chat(name: "林间晚风", message: "那我们周末见！🌿", time: "11:42", initials: "林", colorIndex: 0, unread: 2, isPinned: true, isOnline: true),
        Chat(name: "产品设计小组", message: "Mia：新版本原型已经更新", time: "11:28", initials: "设", colorIndex: 1, unread: 8, isPinned: true),
        Chat(name: "Alex Chen", message: "Sent you the photos 📷", time: "10:56", initials: "A", colorIndex: 2, isOnline: true),
        Chat(name: "周末旅行计划", message: "你：这个地方看起来不错", time: "昨天", initials: "旅", colorIndex: 3, unread: 0),
        Chat(name: "Mia", message: "语音消息 · 0:18", time: "昨天", initials: "M", colorIndex: 4, unread: 0),
        Chat(name: "Luma 公告频道", message: "欢迎来到 Luma ✨", time: "周一", initials: "L", colorIndex: 5, unread: 0)
    ]
}
